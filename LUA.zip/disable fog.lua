local function fogoff()
    client.SetConVar( "fog_enable", 0, true );
    client.SetConVar( "fog_enableskybox", 0, true );
    client.SetConVar( "fog_enable_water_fog", 0, true );
    client.SetConVar( "fog_override", 1, true );
end

local function eventhandler(e)
    if e:GetName() == "round_start" then
       fogoff();
    end        
end

fogoff(); -- Run it when the script starts

client.AllowListener("round_start")
callbacks.Register ("FireGameEvent", eventhandler)