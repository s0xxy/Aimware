-- Modify by: El Credito 04/10/2019 for user from forum aimware ;)

local gui_set = gui.SetValue;
local gui_get = gui.GetValue;
local LeftKey = 0;
local BackKey = 0;
local RightKey = 0;

local rage_ref = gui.Reference("RAGE", "MAIN", "Anti-Aim Main");
local check_indicator = gui.Checkbox(rage_ref, "Enable", "Manual AA", false)
local change_desync = gui.Checkbox(rage_ref, "Enable", "Change desync", false)
local AntiAimleft = gui.Keybox(rage_ref, "Anti-Aim_left", "Left Keybind", 0);
local AntiAimRight = gui.Keybox(rage_ref, "Anti-Aim_Right", "Right Keybind", 0);
local AntiAimBack = gui.Keybox(rage_ref, "Anti-Aim_Back", "Back Keybind", 0);
local AntiAimRangeLeft = gui.Slider(rage_ref, "AntiAimRangeLeft", "AntiAim Range Left", 0, -180, 180);
local AntiAimRangeRight = gui.Slider(rage_ref, "AntiAimRangeRight", "AntiAim Range Right", 0, -180, 180);

local rifk7_font = draw.CreateFont("Verdana", 20, 700)
local damage_font = draw.CreateFont("Verdana", 15, 700)
local arrow_font = draw.CreateFont("Marlett", 37, 500)
local normal = draw.CreateFont("Arial")

local function mainManualAA()
    if (check_indicator:GetValue() ~= true) then
        return
    end

    if AntiAimleft:GetValue() ~= 0 then
        if input.IsButtonPressed(AntiAimleft:GetValue()) then
            setterValue(true, false, false);
        end
    end
    if AntiAimBack:GetValue() ~= 0 then
        if input.IsButtonPressed(AntiAimBack:GetValue()) then
            setterValue(false, false, true);
        end
    end
    if AntiAimRight:GetValue() ~= 0 then
        if input.IsButtonPressed(AntiAimRight:GetValue()) then
        setterValue(false, true, false);
        end
    end
    draw_indicator()
end

function setterValue(left, right, back)
    if (left) then
        if (LeftKey == 1) then
            LeftKey = 0
        else
            LeftKey = 1;RightKey = 0;zBackKey = 0
        end
    elseif (right) then
        if (RightKey == 1) then
            RightKey = 0
        else
            RightKey = 1;LeftKey = 0;BackKey = 0
        end
    elseif (back) then
        if (BackKey == 1) then
            BackKey = 0
        else
            BackKey = 1;LeftKey = 0;RightKey = 0
        end
    end
    changeAA()
end

function changeAA()
    local changeDesync = change_desync:GetValue();
    
    gui_set("rbot_antiaim_autodir", false);    
    gui_set("rbot_antiaim_at_targets", false);
    
    if (LeftKey == 1) then
        gui_set("rbot_antiaim_stand_real_add", AntiAimRangeLeft:GetValue());
        gui_set("rbot_antiaim_move_real_add", AntiAimRangeLeft:GetValue());

        if (changeDesync) then
            gui_set("rbot_antiaim_stand_desync", 2);
            gui_set("rbot_antiaim_move_desync", 2);
        
        end
        
    elseif (RightKey == 1) then
        gui_set("rbot_antiaim_stand_real_add", AntiAimRangeRight:GetValue());
        gui_set("rbot_antiaim_move_real_add", AntiAimRangeRight:GetValue());
        gui_set("rbot_antiaim_autodir", false);
        if (changeDesync) then
            gui_set("rbot_antiaim_stand_desync", 3);
            gui_set("rbot_antiaim_move_desync", 3);
        end
        
    elseif (BackKey == 1) then
        gui_set("rbot_antiaim_stand_real_add", 0);
        gui_set("rbot_antiaim_move_real_add", 0);
        gui_set("rbot_antiaim_autodir", false);
        
        if (changeDesync) then
            gui_set("rbot_antiaim_stand_desync", 1);
            gui_set("rbot_antiaim_move_desync", 1);
        end
    elseif ((LeftKey == 0) and (RightKey == 0) and (BackKey == 0)) then
        gui_set("rbot_antiaim_stand_real_add", 0);
        gui_set("rbot_antiaim_move_real_add", 0);
        gui_set("rbot_antiaim_at_targets", 1);
        gui_set("rbot_antiaim_autodir", 2);
    end
end

function draw_indicator()

    local active = check_indicator:GetValue()

    if active then
        local w, h = draw.GetScreenSize();
        draw.SetFont(rifk7_font)
        if (LeftKey == 1) then
            draw.Color(255, 0, 0, 255)
            draw.Text(6, h - 60, "Manual");
            draw.TextShadow(6, h - 60, "Manual");
            draw.SetFont(arrow_font)
            draw.Text( w/2 - 100, h/2 - 21, "3");
            draw.SetFont(rifk7_font)
        elseif (BackKey == 1) then
            draw.Color(255, 0, 0, 255)
            draw.Text(6, h - 60, "Manual");
            draw.TextShadow(6, h - 60, "Manual");
            draw.SetFont(arrow_font)
            draw.Text( w/2 - 21, h/2 + 60, "6");
            draw.SetFont(rifk7_font)
        elseif (RightKey == 1) then
            draw.Color(255, 0, 0, 255);
            draw.Text(6, h - 60, "Manual");
            draw.TextShadow(6, h - 60, "Manual");
            draw.SetFont(arrow_font)
            draw.Text( w/2 + 60, h/2 - 21, "4");
            draw.SetFont(rifk7_font)
        elseif ((LeftKey == 0) and (BackKey == 0) and (RightKey == 0)) then
            draw.Color(47, 255, 0, 255);
            draw.Text(6, h - 60, "AUTO");
            draw.TextShadow(6, h - 60, "AUTO");
        end
        draw.SetFont(normal)
    end
end
callbacks.Register( "Draw", "mainManualAA", mainManualAA);